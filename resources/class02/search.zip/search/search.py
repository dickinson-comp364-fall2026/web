"""Search algorithms and output formatting.

Author: John MacCormick
Assisted by: GitHub Copilot

This module implements several graph-search strategies (breadth-first search,
depth-first search, uniform-cost search, and A*), along with utilities for
formatting the expanded node tables as LaTeX or Markdown. It also supports
loading graph and heuristic data from TOML files for configuration-driven runs.
"""

import argparse
import heapq
import itertools
from enum import Enum, auto
from pathlib import Path
from tabnanny import verbose

try:
    import tomllib
except ModuleNotFoundError:  # pragma: no cover
    import tomli as tomllib


class SearchMode(Enum):
    """Enumeration describing whether the search should use tree search or graph search."""
    TREE = auto()
    GRAPH = auto()


class SearchAlgorithm(Enum):
    """Supported search strategies for this project."""
    ASTAR = auto()
    BFS = auto()
    DFS = auto()
    UCS = auto()

class SearchNodeStatus(Enum):
    """Lifecycle state for each created search node."""
    READY = auto()
    EXPANDED = auto()
    SKIPPED = auto()
    TERMINAL = auto()


MAX_DEPTH = 10  # Maximum depth for search to prevent infinite loops
MAX_NODES = 10_000  # Maximum number of search nodes created to prevent infinite loops

NODES = [] # Global list to keep track of all created nodes for debugging, testing and printing solutions

class SearchLimitExceededError(RuntimeError):
    """Raised when a search exceeds the maximum depth or node limit."""
    pass



###############################################
# Example showing that A-star graph search is not necessarily
# optimal on admissible but inconsistent heuristic.
###############################################
# heuristic = {'s': 5, 'a': 4, 'b': 0, 't': 0}
# edges = {
#     's': {'a': 2, 'b': 5},
#     'a': {'b': 2},
#     'b': {'t': 2},
# }
# # tree search
# expected_path = ['s', 'a', 'b', 't']
# expected_num_nodes_created = 6
# expected_num_nodes_expanded = 4
# # graph search
# expected_path = ['s', 'b', 't']
# expected_num_nodes_created = 4
# expected_num_nodes_expanded = 3



class SearchNode:
    """Represents a single search state together with path-cost metadata."""
    # static counter for unique IDs
    _id_counter = itertools.count()

    def __init__(self, state, parent=None, g=0, h=0):
        self.state = state
        self.parent = parent
        self.g = g  # Cost from start to this node
        self.h = h  # Heuristic cost from this node to goal
        self.f = g + h  # Total cost
        self.depth = parent.depth + 1 if parent else 0
        # Unique identifier for debugging and tie-breaking
        self.id = next(self._id_counter)
        # For debugging, testing, and printing solutions we keep the status complete list of nodes
        self.status = SearchNodeStatus.READY
        NODES.append(self)

    def __lt__(self, other):
        # Break ties by state name
        return (self.f, self.state, self.id) < (other.f, other.state, other.id)

    def __repr__(self):
        return f"SearchNode(id={self.id}, state={self.state}, parent={self.parent.id if self.parent else None}, g={self.g}, h={self.h}, f={self.f}), depth={self.depth}, status={self.status.name.lower()}"

def _search(edges, start, goal, mode, create_child, 
            verbose=False, max_depth=MAX_DEPTH, max_nodes=MAX_NODES):
    """Shared implementation for the search algorithms.

    The function maintains a frontier queue, handles graph- versus tree-search
    semantics, enforces depth and node limits, and returns the path along with
    bookkeeping counts for validation and reporting.
    """
    frontier = []
    num_nodes_created = 0
    num_nodes_expanded = 0
    start_node = create_child(None, start, 0)
    heapq.heappush(frontier, start_node)
    num_nodes_created += 1
    if verbose:
        print(f'    push {start_node}')
    closed = set() if mode == SearchMode.GRAPH else None

    while frontier:
        current_node = heapq.heappop(frontier)
        if verbose:
            print(f'pop {current_node}')
        current_state = current_node.state
        if mode == SearchMode.GRAPH:
            if current_state in closed:
                current_node.status = SearchNodeStatus.SKIPPED
                if verbose:
                    print(f'skip {current_node}')
                continue
            closed.add(current_state)
        if max_depth is not None and current_node.depth >= max_depth:
            raise SearchLimitExceededError(
                f"Exceeded maximum depth of {max_depth} at node {current_node}")
        if current_state == goal:
            current_node.status = SearchNodeStatus.TERMINAL
            path = get_path(start_node, current_node)
            return path, num_nodes_created, num_nodes_expanded

        current_node.status = SearchNodeStatus.EXPANDED
        num_nodes_expanded += 1

        # sort for deterministic behavior in tests and grading
        for neighbor, cost in sorted(edges.get(current_state, {}).items()):
            if mode == SearchMode.GRAPH and neighbor in closed:
                continue
            new_node = create_child(current_node, neighbor, cost)
            num_nodes_created += 1
            if num_nodes_created is not None and num_nodes_created > max_nodes:
                raise SearchLimitExceededError(
                    f"Exceeded maximum nodes of {max_nodes} at node {new_node}")
            heapq.heappush(frontier, new_node)
            if verbose:
                print(f'    push {new_node}')

    # Return None if no path is found
    return None, num_nodes_created, num_nodes_expanded


def astar_search(edges, heuristic, start, goal, mode: SearchMode, verbose=False):
    """Run A* search using the supplied heuristic map."""
    def create_child(parent, state, cost):
        g = 0 if parent is None else parent.g + cost
        return SearchNode(state, parent=parent, g=g, h=heuristic[state])

    return _search(edges, start, goal, mode, create_child, verbose)

def ucs_search(edges, start, goal, mode: SearchMode, verbose=False):
    """Run uniform-cost search, equivalent to A* with a zero heuristic."""
    def create_child(parent, state, cost):
        g = 0 if parent is None else parent.g + cost
        return SearchNode(state, parent=parent, g=g, h=0)

    return _search(edges, start, goal, mode, create_child, verbose)



def dfs_search(edges, start, goal, mode: SearchMode, verbose=False):
    """Run depth-first search using a decreasing g-cost encoding."""
    def create_child(parent, state, _):
        g = 0 if parent is None else parent.g - 1
        new_node = SearchNode(state, parent=parent, g=g)
        assert new_node.g == -new_node.depth, (
            f"g={new_node.g} should equal -depth={-new_node.depth}")
        return new_node

    return _search(edges, start, goal, mode, create_child, verbose, MAX_DEPTH)

def bfs_search(edges, start, goal, mode: SearchMode, verbose=False):
    """Run breadth-first search using unit-depth increments for g."""
    def create_child(parent, state, _):
        g = 0 if parent is None else parent.g + 1
        new_node = SearchNode(state, parent=parent, g=g)
        assert new_node.g == new_node.depth, (
            f"g={new_node.g} should equal depth={new_node.depth}")
        return new_node

    return _search(edges, start, goal, mode, create_child, verbose, MAX_DEPTH)


def get_path(start, current):
    """Reconstruct the path from the start node to the current node.

    Returns the nodes in order from start to goal, following parent pointers.
    """
    reverse_path = []
    while current.parent is not None:
        reverse_path.append(current)
        current = current.parent
    reverse_path.append(start)
    path = reverse_path[::-1]  # Reverse the path to get it from start to goal
    return path


def format_nodes_latex(nodes, include_heuristic=True, include_depth=True, include_g=True, include_f=True, path=None):
    """Format the search node table as a LaTeX tabular block.

    The optional include_* arguments allow the caller to omit columns when a
    particular value is not relevant to the current run.
    """
    headers = [
        r"\textbf{index}", r"\textbf{state}", r"\textbf{parent}",
    ]
    if include_depth:
        headers.append(r"\textbf{depth}")
    if include_g:
        headers.append(r"\textbf{cost $g$}")
    if include_heuristic:
        headers.append(r"\textbf{heuristic $h$}")
    if include_f:
        headers.append(r"\textbf{priority $f$}")
    headers.append(r"\textbf{status}")

    tabular_spec = "c " * len(headers)
    tabular_spec = tabular_spec.rstrip()

    lines = [
        rf"\begin{{tabular}}{{{tabular_spec}}}",
        r"\toprule",
        " & ".join(headers) + r" \\",
        r"\midrule",
    ]
    node_indices = {node: node.id for node in nodes}
    for node in nodes:
        status = {
            SearchNodeStatus.READY: "",
            SearchNodeStatus.EXPANDED: "x",
            SearchNodeStatus.SKIPPED: "sk",
            SearchNodeStatus.TERMINAL: "t",
        }[node.status]
        parent = node_indices[node.parent] if node.parent else "--"
        row = [str(node.id), node.state, str(parent)]
        if include_depth:
            row.append(str(node.depth))
        if include_g:
            row.append(str(node.g))
        if include_heuristic:
            row.append(str(node.h))
        if include_f:
            row.append(str(node.f))
        row.append(status)
        lines.append(" & ".join(row) + r" \\")
    lines.extend([r"\bottomrule", r"\end{tabular}"])
    if path:
        states = r" \to ".join(node.state for node in path)
        lines.append(r"\par \smallskip \textbf{Path found:} $" + states + "$")
    elif path is not None:
        lines.append(r"\par \smallskip \textbf{No path found.}")
    return "\n".join(lines)


def format_nodes_markdown(nodes, include_heuristic=True, include_depth=True, include_g=True, include_f=True, path=None):
    """Format the search node table as a Markdown table with aligned columns."""
    headers = ["index", "state", "parent"]
    if include_depth:
        headers.append("depth")
    if include_g:
        headers.append("g")
    if include_heuristic:
        headers.append("h")
    if include_f:
        headers.append("f")
    headers.append("status")
    node_indices = {node: node.id for node in nodes}
    rows = []
    for node in nodes:
        status = {
            SearchNodeStatus.READY: "",
            SearchNodeStatus.EXPANDED: "x",
            SearchNodeStatus.SKIPPED: "sk",
            SearchNodeStatus.TERMINAL: "t",
        }[node.status]
        parent = str(node_indices[node.parent]) if node.parent else "--"
        row = [str(node.id), node.state, parent]
        if include_depth:
            row.append(str(node.depth))
        if include_g:
            row.append(str(node.g))
        if include_heuristic:
            row.append(str(node.h))
        if include_f:
            row.append(str(node.f))
        row.append(status)
        rows.append(row)

    widths = [max(len(header), *(len(row[i]) for row in rows)) for i, header in enumerate(headers)]

    def format_row(cells):
        return "| " + " | ".join(cell.ljust(width) for cell, width in zip(cells, widths)) + " |"

    lines = [
        format_row(headers),
        "|" + "|".join("-" * (width + 2) for width in widths) + "|",
    ]
    lines.extend(format_row(row) for row in rows)
    table = "\n".join(lines)

    if path:
        states = " -> ".join(node.state for node in path)
        table += f"\n\n**Path found:** {states}"
    elif path is not None:
        table += "\n\n**No path found.**"
    return table


def load_graph_file(path):
    """Load graph edges and heuristic values from a TOML file.

    If a heuristic table is missing, each reachable node is assigned a default
    value of zero. This keeps the file format flexible while preserving the
    expectation that every search algorithm can always access a heuristic map.

    Example TOML file format:
    [edges]
    s = {a = 1, b = 4}
    a = {c = 3}
    b = {c = 1}
    c = {t = 2}
    t = {}

    [heuristic]
    s = 6
    a = 5
    b = 1
    c = 1
    t = 0
    """
    config_path = Path(path)
    if not config_path.is_absolute():
        candidates = [
            Path.cwd() / config_path,
            Path(__file__).resolve().parent / config_path,
            Path(__file__).resolve().parent / 'input' / config_path.name,
        ]
        for candidate in candidates:
            if candidate.exists():
                config_path = candidate
                break
        else:
            config_path = candidates[0]

    with config_path.open('rb') as toml_file:
        data = tomllib.load(toml_file)

    edges = {
        node: {
            neighbor: float(cost) if isinstance(cost, (int, float)) and cost % 1 != 0 else int(cost)
            for neighbor, cost in neighbors.items()
        }
        for node, neighbors in data.get('edges', {}).items()
    }

    heuristic_data = data.get('heuristic', {})
    all_nodes = set(edges)
    for neighbors in edges.values():
        all_nodes.update(neighbors)
    heuristic = {node: int(heuristic_data.get(node, 0)) for node in sorted(all_nodes)}
    return edges, heuristic


def main():
    """Run the configured search and emit the formatted node tables."""
    args = parse_arguments()
    start_node = args.start
    goal_node = args.goal
    mode = SearchMode.TREE if args.use_tree_search else SearchMode.GRAPH
    edges, heuristic = load_graph_file(args.input_file)

    match args.algorithm:
        case SearchAlgorithm.ASTAR:
            result = astar_search(
                edges, heuristic, start_node, goal_node, mode=mode, verbose=args.verbose)
        case SearchAlgorithm.BFS:
            result = bfs_search(edges, start_node, goal_node,
                         mode=mode, verbose=args.verbose)
        case SearchAlgorithm.DFS:
            result = dfs_search(edges, start_node, goal_node,
                         mode=mode, verbose=args.verbose)
        case SearchAlgorithm.UCS:
            result = ucs_search(edges, start_node, goal_node,
                         mode=mode, verbose=args.verbose)
        case _:
            raise ValueError(f"Unhandled algorithm: {args.algorithm}")

    path, num_nodes_created, num_nodes_expanded = result
    node_path = [node.state for node in path] if path else None
    include_heuristic = not args.hide_heuristic
    include_depth = not args.hide_depth
    include_g = not args.hide_g
    include_f = not args.hide_f
    latex_source = format_nodes_latex(
        NODES,
        include_heuristic=include_heuristic,
        include_depth=include_depth,
        include_g=include_g,
        include_f=include_f,
        path=path,
    )
    with open(args.latex_output, "w", encoding="utf-8") as output_file:
        output_file.write(latex_source)

    markdown_source = format_nodes_markdown(
        NODES,
        include_heuristic=include_heuristic,
        include_depth=include_depth,
        include_g=include_g,
        include_f=include_f,
        path=path,
    )
    with open(args.markdown_output, "w", encoding="utf-8") as output_file:
        output_file.write(markdown_source)

    if args.verbose:
        print(f"\n\nAll nodes:\n{'\n'.join(str(node) for node in NODES)}")
    print(f"LaTeX source saved to: {args.latex_output}")
    print(f"Markdown table saved to: {args.markdown_output}")
    print(f"\n\n{markdown_source}")
    # if path:
    #     print(f"\n\nPath found: {' -> '.join(node_path)}")
    # else:
    #     print("No path found.")
    print(f"Number of nodes created: {num_nodes_created}")
    print(f"Number of nodes expanded: {num_nodes_expanded}")


def parse_algorithm(s):
    """Parse a textual algorithm name into the corresponding SearchAlgorithm enum."""
    try:
        return SearchAlgorithm[s.upper()]
    except KeyError:
        raise argparse.ArgumentTypeError(
            f"invalid choice: '{s}' (choose from {[e.name.lower() for e in SearchAlgorithm]})"
        )


def parse_arguments():
    """Configure the command-line interface for search runs and output options."""
    parser = argparse.ArgumentParser(description="A* Search Algorithm")
    parser.add_argument("--start", type=str, default='s', help="Start node")
    parser.add_argument("--goal", type=str, default='t', help="Goal node")
    parser.add_argument("-ts", "--use-tree-search", action='store_true',
                        dest='use_tree_search', default=False,
                        help="Use tree search (default is graph search)")
    parser.add_argument(
        '--algorithm', '-a',
        type=parse_algorithm,
        default=SearchAlgorithm.ASTAR,
        help=f"Search algorithm to use ({', '.join(e.name.lower() for e in SearchAlgorithm)}). Default is astar; ucs means uniform cost search, which is A* with a zero heuristic.",
    )
    parser.add_argument('-v', '--verbose', action='store_true',
                        help='Enable verbose output')
    parser.add_argument('-hh', '--hide-heuristic', action='store_true', default=False,
                        help='Hide the heuristic (h) column from output tables')
    parser.add_argument('-hd', '--hide-depth', action='store_true', default=False,
                        help='Hide the depth column from output tables')
    parser.add_argument('-hg', '--hide-g', action='store_true', default=False,
                        help='Hide the cost (g) column from output tables')
    parser.add_argument('-hf', '--hide-f', action='store_true', default=False,
                        help='Hide the priority (f) column from output tables')
    parser.add_argument('--input-file', default='input/graph.toml',
                        help='TOML file containing the graph edges and heuristic values')
    parser.add_argument('--latex-output', default='solution.tex',
                        help='File to save the LaTeX solution table to')
    parser.add_argument('--markdown-output', default='solution.md',
                        help='File to save the Markdown solution table to')
    return parser.parse_args()


if __name__ == "__main__":
    main()
